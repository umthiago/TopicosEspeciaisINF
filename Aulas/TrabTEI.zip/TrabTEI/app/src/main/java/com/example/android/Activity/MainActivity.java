package com.example.android.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.android.Fragment.LojasFragment;
import com.example.android.Fragment.ProdutosFragment;

import com.example.android.R;

public class MainActivity extends AppCompatActivity {

    private Button buttonConversa, buttonContato;
    private ProdutosFragment produtosFragment;
    private LojasFragment lojasFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buttonContato = findViewById(R.id.ButtonContato);
        buttonConversa = findViewById(R.id.ButtonConversas);


        produtosFragment = new ProdutosFragment();

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.FrameConteudo, produtosFragment);
        transaction.commit();


        buttonContato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lojasFragment = new LojasFragment();

                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.FrameConteudo, lojasFragment);
                transaction.commit();
            }
        });

        buttonConversa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                produtosFragment = new ProdutosFragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.FrameConteudo, produtosFragment);
                transaction.commit();
            }
        });
    }
}