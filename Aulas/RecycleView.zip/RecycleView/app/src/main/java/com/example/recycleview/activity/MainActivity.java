package com.example.recycleview.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.recycleview.R;
import com.example.recycleview.adapter.Adapter;
import com.example.recycleview.model.Filme;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public RecyclerView recyclerView;
    private List<Filme> listaFilmes = new ArrayList<>();


    public void criarFilmes(){
        Filme filme = new Filme("Homem Aranha", "Aventura", "2018");
        this.listaFilmes.add(filme);
        filme = new Filme("Free Guy", "Fantasia", "2021");
        this.listaFilmes.add(filme);
        filme = new Filme("Viagem 2", "Aventura", "2012");
        this.listaFilmes.add(filme);
        filme = new Filme("Como treinar seu dragão", "Animação", "2010");
        this.listaFilmes.add(filme);
        filme = new Filme("Kingsman: Serviço Secreto", "Aventura", "2018");
        this.listaFilmes.add(filme);
        filme = new Filme("Oppenheimer", "Drama", "2023");
        this.listaFilmes.add(filme);
        filme = new Filme("Megatubarão 2", "Ficção Ciêntifica", "2018");
        this.listaFilmes.add(filme);
        filme = new Filme("Smurfs", "Ficção Ciêntifica", "2009");
        this.listaFilmes.add(filme);
        filme = new Filme("A origem dos guardiões", "Animação", "2015");
        this.listaFilmes.add(filme);
        filme = new Filme("Batman", "Ação", "2019");
        this.listaFilmes.add(filme);
    }

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        //Configurar
        Adapter adapter = new Adapter(listaFilmes);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
    }
}