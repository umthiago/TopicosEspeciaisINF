package com.example.recycleview.model;

public class Filme {
    private String títuloFilme;
    private String genero;
    private String ano;

    public Filme(){

    }

    public String getTítuloFilme() {
        return títuloFilme;
    }

    public void setTítuloFilme(String títuloFilme) {
        this.títuloFilme = títuloFilme;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public Filme(String títuloFilme, String genero, String ano) {
        this.títuloFilme = títuloFilme;
        this.genero = genero;
        this.ano = ano;
    }
}
